var MY_CONSTANT = "this is my constant";

export { MY_CONSTANT };
