export declare const MY_CONSTANT = 'this is my constant'; 
